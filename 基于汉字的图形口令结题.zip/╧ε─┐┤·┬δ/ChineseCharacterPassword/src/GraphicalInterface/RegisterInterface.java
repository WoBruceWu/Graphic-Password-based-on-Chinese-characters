package GraphicalInterface;

import javax.swing.JFrame;

public class RegisterInterface extends JFrame{
	

}
