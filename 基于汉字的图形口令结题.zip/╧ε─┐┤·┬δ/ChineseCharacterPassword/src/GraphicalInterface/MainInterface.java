package GraphicalInterface;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Label;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.util.Random;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.plaf.DimensionUIResource;
import javax.swing.text.StyledEditorKit.ForegroundAction;

import com.bean.ChineseCharacter;
import com.tool.UserManager;

public class MainInterface extends JFrame{
	public static int N=3;
	public Grid grid[][]=new Grid[N][N];
	JPanel Board=new JPanel();
	JTextField inputIdField=new JTextField();
	JTextField pawField=new JTextField();
	JPanel usrPannel=new JPanel();
	JLabel label1=new JLabel();
	JLabel label2=new JLabel(); 
	JPanel optionPanel=new JPanel();
	Button butnReInput=new Button("��������");
	Button butnRegister=new Button("ע��");
	Button butnLogin=new Button("��¼");
	public MainInterface() {
		// TODO Auto-generated constructor stub
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				grid[i][j]=new Grid(i,j);
				grid[i][j].setText("");
				grid[i][j].setVisible(true);
				//grid[i][j].setFont(new Font("�����п�",Font.BOLD,60));
				grid[i][j].setFont(new Font(null,Font.BOLD,60));
				chooseCharacter(i,j);
				Board.add(grid[i][j]);
			}		
		}
		setTitle("����ͼ�ο���");
		setBounds(200, 15, 300, 300);
		setLayout(new BorderLayout());
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Board.setLayout(new GridLayout(N, N));
//		
		
		this.add("Center",Board);
		optionPanel.add(butnReInput); 
		//optionPanel.add(butnRegister);
		optionPanel.add(butnLogin);
		optionPanel.setLayout(new GridLayout(1,3,20,20));
		
		usrPannel.setLayout(new GridLayout(2, 2,-150,0));
		
		label1.setText("�˺ţ�");
		label1.setPreferredSize(new DimensionUIResource(50, 25));
		inputIdField.setPreferredSize(new DimensionUIResource(50, 25));
		inputIdField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				super.focusGained(e);
				pawField.setFocusable(true);
			}
		});
		
		label2.setText("���룺");
		
		label2.setPreferredSize(new DimensionUIResource(50, 25));
		
		pawField.setPreferredSize(new DimensionUIResource(50, 25));
		pawField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				super.focusGained(e);
				pawField.setFocusable(true);
				pawField.setText("");
				Grid.turn=0;
				UserManager.Correct=true;
				try {
					if(UserManager.isExistedUser(inputIdField.getText())){
						System.out.println(UserManager.getPassword());
						setTurn(0);
						pawField.setFocusable(false);
					}
					else{
						JOptionPane.showMessageDialog(null,inputIdField.getText()+":���û������ڣ�","����",
					            JOptionPane.WARNING_MESSAGE,
					            null);
						pawField.setFocusable(false);
					}
				} catch (HeadlessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		usrPannel.add(label1);
		usrPannel.add(inputIdField);
		usrPannel.add(label2);
		usrPannel.add(pawField);
		
		this.add("North",usrPannel);		
		
		this.add("South",optionPanel);
		
		butnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseClicked(e);
				if(UserManager.Correct){
					JOptionPane.showMessageDialog(null,"������ȷ��","��ȷ��",JOptionPane.CLOSED_OPTION );
				}
				else{
					JOptionPane.showMessageDialog(null,"�������","����",
                            JOptionPane.WARNING_MESSAGE,
                            null);
				}
			}
		});
		
		butnReInput.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseClicked(e);
				undo();
			}
		});
		setVisible(true);
	}
	
	public void chooseCharacter(int i, int j) {
		// TODO Auto-generated method stub
		grid[i][j].addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseClicked(e);
				Grid tempGrid=(Grid)(e.getSource());
				String password=pawField.getText();
				password+=tempGrid.character.ch;
				pawField.setText(password);
				
				
				
				if(tempGrid.isChTrue){
					System.out.println("right");
				}
				else{
					UserManager.Correct=false;
				}
				
				Grid.turn+=1;
				setTurn(Grid.turn);
			}
		});
	}
	
/**
 * ������һ�ֵ��ַ�
 * @param turn
 */
	public void setTurn(int turn){
		String password=UserManager.getPassword();
		
		if(turn<password.length()){
		char ch=password.charAt(turn);
		Random random=new Random();
		int ikey=random.nextInt(N);
		int jkey=random.nextInt(N);
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				char nch=ChineseCharacter.TransferFalse(ch);
				//System.out.println(nch);
				grid[i][j].setText(""+nch);
				grid[i][j].isChTrue=false;
			}
		}
		grid[ikey][jkey].setText(""+ChineseCharacter.TransferTrue(ch));
		grid[ikey][jkey].isChTrue=true;
		}
	}

/**
 * ������ǰ���������
 */
	public void undo(){
		pawField.setText("");
		UserManager.Correct=true;
		Grid.turn=0;
		
		setTurn(0);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(new MainInterface().grid[1][2]);
	}

}
