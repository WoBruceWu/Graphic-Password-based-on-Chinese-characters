package GraphicalInterface;

import javax.swing.JButton;

import com.bean.ChineseCharacter;

public class Grid extends JButton{
	public int x;public int y;
	public static int turn=0;
	public ChineseCharacter character; //��Ӧ�ĺ���
	public boolean isChTrue;
	public Grid(int x,int y){
		this.x=x;
		this.y=y;
//		this.setIcon(new Resources().smallIcon);
	}
}
