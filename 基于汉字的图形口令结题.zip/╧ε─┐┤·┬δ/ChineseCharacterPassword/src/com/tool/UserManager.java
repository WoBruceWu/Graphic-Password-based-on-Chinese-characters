package com.tool;
import java.awt.print.Printable;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.net.URLEncoder;
import java.nio.charset.Charset;

import com.bean.User;


public class UserManager {
	public static String DATA_FILE="user.txt";
	private static final Charset FILE_CHARSET = Charset.forName("utf-8");
	private static String password="";
	public static boolean Correct=true;
	public static boolean isExistedUser(String username) throws FileNotFoundException{
		
		//InputStream in = UserManager.class.getResourceAsStream(DATA_FILE);

		InputStream in=new FileInputStream(new File(DATA_FILE));
		
		BufferedReader br = new BufferedReader(new InputStreamReader(in, FILE_CHARSET));
		
		String tempString=null;
		int line=1;
		try {
			br.readLine();
			while((tempString=br.readLine())!=null){
				String stru[]=tempString.split("\\|");
				if(stru[0].equals(username)){	
					setPassword(stru[1]);
					return true;									
				}
			}
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean register(User user) throws FileNotFoundException{
//		InputStream in = UserManager.class.getResourceAsStream(DATA_FILE);
		InputStream in=new FileInputStream(new File(DATA_FILE));
		BufferedReader br = new BufferedReader(new InputStreamReader(in, FILE_CHARSET));
		String tempString=null;
		int line=1;
		try {
			br.readLine();
			while((tempString=br.readLine())!=null){
				String stru[]=tempString.split("\\|");
				if(stru[0].equals(user.getUsername())){	
					setPassword(stru[1]);
					return false;
				}
			}
			br.close();
			
			RandomAccessFile randomAccessFile=new RandomAccessFile(DATA_FILE, "rw");
			long fileLength=randomAccessFile.length();
			
			
			randomAccessFile.seek(fileLength);
			
			
			
			randomAccessFile.write(("\n"+user.getUsername()+"|"+user.getPassword()).getBytes());
			
			randomAccessFile.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;	
	}
	
	
	public static boolean isCorretCharacter(){
		return false;
	}
	
	public static String getPassword(){	
		return password;
	}
	
	public static void setPassword(String str){
		password=str;
	}
	
	public static void main(String[]args) throws IOException{
		//String username=URLEncoder.encode(new String("brucewu1234".getBytes()), "UTF-8");
		//String password=URLEncoder.encode(new String("�쿪��ʤ".getBytes()), "UTF-8");
		User user=new User("brucewu1234","�쿪��ʤ");
		register(user);
		
		
	}
	
}
