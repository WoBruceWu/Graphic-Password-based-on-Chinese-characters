package com.bean;

import java.util.Random;

import com.dic.Dict;
import com.spreada.utils.chinese.ZHConverter;

public class ChineseCharacter {
	public static char ch='*'; 
	public static boolean isChTure=true;
	public static char TransferTrue(char ch){
		//char BS=(Dict.getBS(ch)).charAt(0);
		//System.out.println(BS);
		Random random=new Random();
		char nch='һ';
		while(true){
			int r=random.nextInt(30);
			nch=(char)(ch+r);
			if((Dict.getBS(nch)).equals(Dict.getBS(ch)))
				break;
		}
		ZHConverter converter = ZHConverter.getInstance(ZHConverter.SIMPLIFIED);
		String traditionalSrc=String.valueOf(nch);
		nch=converter.convert(traditionalSrc).charAt(0);
		return nch;
		//return BS;
	}
	
	public static char TransferFalse(char ch){
		//char BS=(Dict.getBS(ch)).charAt(0);
		Random random=new Random();
		char nch='һ';
		while(true){
			int r=100+random.nextInt(1000);
			nch=(char)(ch+r);
			if(!((Dict.getBS(nch)).equals(Dict.getBS(ch))))
				break;
		}
		/**
		 * ���ַ���ת��Ϊ����
		 */
		ZHConverter converter = ZHConverter.getInstance(ZHConverter.SIMPLIFIED);
		String traditionalSrc=String.valueOf(nch);
		nch=converter.convert(traditionalSrc).charAt(0);
		return nch;
		//return '��';
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println((ChineseCharacter.TransferTrue('��')));
		System.out.println((ChineseCharacter.TransferFalse('��')));
		System.out.println();
		
		
	}

}
