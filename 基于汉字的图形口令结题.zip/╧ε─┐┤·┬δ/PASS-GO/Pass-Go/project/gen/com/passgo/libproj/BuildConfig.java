/** Automatically generated file. DO NOT MODIFY */
package com.passgo.libproj;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}